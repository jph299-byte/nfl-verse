const WEEK1_SITUATION_RESULTS = [
  {away:"ARI",home:"LAC",actual:[26.000,14.000],rawSitu:[56.703,17.560],situ:[41.212,20.956],quality:"A"},
  {away:"ATL",home:"PIT",actual:[13.000,20.000],rawSitu:[14.145,20.291],situ:[19.189,22.369],quality:"A"},
  {away:"BAL",home:"IND",actual:[41.000,23.000],rawSitu:[36.868,22.217],situ:[30.948,23.366],quality:"A"},
  {away:"BUF",home:"HOU",actual:[36.000,31.000],rawSitu:[29.048,35.065],situ:[26.901,30.015],quality:"A"},
  {away:"CHI",home:"CAR",actual:[59.000,37.000],rawSitu:[49.191,39.301],situ:[37.324,32.206],quality:"A"},
  {away:"CLE",home:"JAC",actual:[10.000,34.000],rawSitu:[17.378,42.881],situ:[20.862,34.059],quality:"A"},
  {away:"DAL",home:"NYG",actual:[20.000,28.000],rawSitu:[31.985,46.404],situ:[28.421,35.882],quality:"A"},
  {away:"DEN",home:"KC",actual:[10.000,31.000],rawSitu:[1.934,29.340],situ:[12.870,27.052],quality:"A"},
  {away:"GB",home:"MIN",actual:[22.000,39.000],rawSitu:[19.642,25.947],situ:[22.034,25.296],quality:"A"},
  {away:"MIA",home:"LV",actual:[13.000,27.000],rawSitu:[10.450,34.609],situ:[17.277,29.778],quality:"A"},
  {away:"NE",home:"SEA",actual:[10.000,13.000],rawSitu:[23.702,19.138],situ:[24.134,21.773],quality:"A"},
  {away:"NO",home:"DET",actual:[30.000,31.000],rawSitu:[38.593,38.797],situ:[31.840,31.946],quality:"A"},
  {away:"NYJ",home:"TEN",actual:[23.000,10.000],rawSitu:[35.873,21.468],situ:[30.433,22.978],quality:"A"},
  {away:"SF",home:"LAR",actual:[27.000,7.000],rawSitu:[51.660,32.811],situ:[38.602,28.848],quality:"A"},
  {away:"TB",home:"CIN",actual:[27.000,33.000],rawSitu:[28.068,43.587],situ:[26.394,34.425],quality:"A"},
  {away:"WAS",home:"PHI",actual:[22.000,24.000],rawSitu:[26.231,13.566],situ:[25.443,18.889],quality:"A"}
];
