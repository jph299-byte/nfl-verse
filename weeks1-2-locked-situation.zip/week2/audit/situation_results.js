const WEEK2_SITUATION_RESULTS = [
  {away:"CAR",home:"ATL",actual:[34.000,3.000],rawSitu:[18.268,25.619],situ:[21.323,25.126],quality:"A"},
  {away:"CIN",home:"HOU",actual:[20.000,6.000],rawSitu:[15.605,20.883],situ:[19.944,22.676],quality:"A"},
  {away:"CLE",home:"TB",actual:[23.000,19.000],rawSitu:[24.747,26.097],situ:[24.675,25.374],quality:"A"},
  {away:"DET",home:"BUF",actual:[31.000,41.000],rawSitu:[25.707,51.225],situ:[25.172,38.377],quality:"A"},
  {away:"GB",home:"NYJ",actual:[20.000,17.000],rawSitu:[11.107,22.551],situ:[17.617,23.539],quality:"A"},
  {away:"IND",home:"KC",actual:[30.000,33.000],rawSitu:[37.742,53.391],situ:[31.400,39.498],quality:"A"},
  {away:"JAC",home:"DEN",actual:[13.000,20.000],rawSitu:[26.386,34.480],situ:[25.523,29.712],quality:"A"},
  {away:"LV",home:"LAC",actual:[26.000,14.000],rawSitu:[16.843,13.843],situ:[20.585,19.033],quality:"CHECK"},
  {away:"MIA",home:"SF",actual:[13.000,35.000],rawSitu:[13.880,38.424],situ:[19.052,31.753],quality:"A"},
  {away:"MIN",home:"CHI",actual:[9.000,3.000],rawSitu:[22.968,16.856],situ:[23.755,20.592],quality:"A"},
  {away:"NO",home:"BAL",actual:[24.000,17.000],rawSitu:[30.212,34.743],situ:[27.503,29.848],quality:"A"},
  {away:"PHI",home:"TEN",actual:[24.000,20.000],rawSitu:[34.858,20.160],situ:[29.907,22.302],quality:"A"},
  {away:"PIT",home:"NE",actual:[3.000,20.000],rawSitu:[28.135,19.017],situ:[26.429,21.710],quality:"A"},
  {away:"SEA",home:"ARI",actual:[31.000,7.000],rawSitu:[40.161,17.649],situ:[32.651,21.002],quality:"A"},
  {away:"WAS",home:"DAL",actual:[20.000,37.000],rawSitu:[39.624,39.738],situ:[32.374,32.432],quality:"A"}
];
