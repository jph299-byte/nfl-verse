# Situation v3 audit package

This is the **audit-stage** implementation of the locked 2026-09-22 rules.

It intentionally does **not** overwrite `convert_week.R` or the production calibration yet.
The existing exact-play files filtered normal punts/kickoffs before scoring, so a production
recalibration from those CSVs would be invalid.

Run the included workflow after placing `weeks1-2-locked-situation.zip` in the repository.
Download the `situation-v3-audit` artifact and inspect `CAR_ATL_v3_play_by_play.csv`.

After the audit is approved, the same scoring/classification rules should be moved upstream
into `convert_week.R`, where all fourth downs, punts, field goals and kickoffs are retained,
and then the full 2025 calibration must be rebuilt from raw data.
